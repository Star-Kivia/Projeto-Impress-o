namespace PrintFlowAI.Models
{
    public class DashboardViewModel
    {
        public int OSPendentes { get; set; }
        public int OSEmProducao { get; set; }
        public int OSConcluidas { get; set; }
        public double Eficiencia { get; set; }
        public List<Impressora> Impressoras { get; set; } = new();
        public List<OrdemServico> FilaProducao { get; set; } = new();
        public string UsuarioLogado { get; set; } = string.Empty;
        public TipoUsuario TipoUsuario { get; set; }
    }
}