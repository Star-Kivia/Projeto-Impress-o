using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PrintFlowAI.Models
{
    public class Impressora
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        
        [Required]
        [MaxLength(50)]
        public string Nome { get; set; } = string.Empty;
        
        public int VelocidadeMinutos { get; set; }
        
        [Required]
        public StatusImpressora Status { get; set; } = StatusImpressora.Disponivel;
        
        [Required]
        [MaxLength(20)]
        public string Categoria { get; set; } = string.Empty;
        
        public int? OrdemServicoAtualId { get; set; }
        
        public DateTime? DataManutencao { get; set; }
    }

    public enum StatusImpressora
    {
        Disponivel,
        Ocupada,
        Manutencao
    }
}