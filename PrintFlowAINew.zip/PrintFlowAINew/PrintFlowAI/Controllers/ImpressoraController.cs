using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using PrintFlowAI.Models;
using PrintFlowAI.Data;

namespace PrintFlowAI.Controllers
{
    [Authorize(Roles = "Impressao")]
    public class ImpressoraController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ImpressoraController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var impressoras = await _context.Impressoras.ToListAsync();
            return View(impressoras);
        }

        [HttpPost]
        public async Task<IActionResult> AtualizarStatus(int id, StatusImpressora novoStatus)
        {
            var impressora = await _context.Impressoras.FindAsync(id);
            if (impressora != null)
            {
                impressora.Status = novoStatus;
                if (novoStatus == StatusImpressora.Manutencao)
                {
                    impressora.DataManutencao = DateTime.Now;
                    impressora.OrdemServicoAtualId = null;
                }
                
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Index");
        }
    }
}