using Microsoft.AspNetCore.Mvc;

namespace PrintFlowAI.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class BaseApiController : ControllerBase
    {
    }
}