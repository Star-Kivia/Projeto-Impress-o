using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using PrintFlowAI.Services;

namespace PrintFlowAI.Controllers.Api
{
    [Authorize]
    public class AnalyticsController : BaseApiController
    {
        private readonly AnalyticsService _analyticsService;

        public AnalyticsController(AnalyticsService analyticsService)
        {
            _analyticsService = analyticsService;
        }

        [HttpGet("metricas-periodo")]
        public async Task<IActionResult> GetMetricasPeriodo([FromQuery] DateTime? inicio = null, [FromQuery] DateTime? fim = null)
        {
            try
            {
                var dataInicio = inicio ?? DateTime.Now.AddDays(-7);
                var dataFim = fim ?? DateTime.Now;

                var metricas = await _analyticsService.GetMetricasPeriodo(dataInicio, dataFim);
                return Ok(metricas);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao buscar métricas do período", details = ex.Message });
            }
        }

        [HttpGet("eficiencia-impressoras")]
        public async Task<IActionResult> GetEficienciaImpressoras()
        {
            try
            {
                var eficiencia = await _analyticsService.GetEficienciaImpressoras();
                return Ok(eficiencia);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao buscar eficiência das impressoras", details = ex.Message });
            }
        }

        [HttpGet("previsao-producao")]
        public async Task<IActionResult> GetPrevisaoProducao()
        {
            try
            {
                var previsao = await _analyticsService.GetPrevisaoProducao();
                return Ok(previsao);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao buscar previsão de produção", details = ex.Message });
            }
        }

        [HttpGet("dashboard-completo")]
        public async Task<IActionResult> GetDashboardCompleto()
        {
            try
            {
                var metricasPeriodo = await _analyticsService.GetMetricasPeriodo(DateTime.Now.AddDays(-7), DateTime.Now);
                var eficiencia = await _analyticsService.GetEficienciaImpressoras();
                var previsao = await _analyticsService.GetPrevisaoProducao();

                return Ok(new
                {
                    MetricasPeriodo = metricasPeriodo,
                    EficienciaImpressoras = eficiencia,
                    PrevisaoProducao = previsao,
                    UltimaAtualizacao = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao buscar dashboard completo", details = ex.Message });
            }
        }
    }
}