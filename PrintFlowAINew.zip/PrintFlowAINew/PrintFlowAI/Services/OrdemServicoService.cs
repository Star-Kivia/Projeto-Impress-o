using PrintFlowAI.Models;

namespace PrintFlowAI.Services
{
    public class OrdemServicoService
    {
        private readonly AlgoritmoDistribuicaoService _algoritmo;

        public OrdemServicoService(AlgoritmoDistribuicaoService algoritmo)
        {
            _algoritmo = algoritmo;
        }

        public class ProcessamentoResultado
        {
            public PrioridadeOS Prioridade { get; set; }
            public int TempoEstimado { get; set; }
            public int? ImpressoraId { get; set; }
            public int Pontuacao { get; set; }
            public string Motivo { get; set; } = string.Empty;
        }

        public ProcessamentoResultado ProcessarNovaOS(OrdemServico os, List<Impressora> impressoras)
        {
            var resultado = _algoritmo.DistribuirOS(os, impressoras);

            return new ProcessamentoResultado
            {
                Prioridade = ClassificarPrioridade(os),
                TempoEstimado = resultado.TempoEstimado,
                ImpressoraId = resultado.ImpressoraId,
                Pontuacao = resultado.Pontuacao,
                Motivo = resultado.Motivo
            };
        }

        public ProcessamentoResultado DistribuirOS(OrdemServico os, List<Impressora> impressoras)
        {
            var resultado = _algoritmo.DistribuirOS(os, impressoras);

            return new ProcessamentoResultado
            {
                Prioridade = ClassificarPrioridade(os),
                TempoEstimado = resultado.TempoEstimado,
                ImpressoraId = resultado.ImpressoraId,
                Pontuacao = resultado.Pontuacao,
                Motivo = resultado.Motivo
            };
        }

        private PrioridadeOS ClassificarPrioridade(OrdemServico os)
        {
            if (os.PrazoEntrega <= DateTime.Now.AddHours(24))
                return PrioridadeOS.Urgente;
            
            if (os.UsaPantone || os.TipoPapel.Contains("especial") || os.TipoPapel.Contains("premium"))
                return PrioridadeOS.Tecnico;
            
            if (os.Quantidade > 1000)
                return PrioridadeOS.Producao;
            
            return PrioridadeOS.Padrao;
        }
    }
}