using PrintFlowAI.Models;
using PrintFlowAI.Data;
using Microsoft.EntityFrameworkCore;

namespace PrintFlowAI.Services
{
    public class AnalyticsService
    {
        private readonly ApplicationDbContext _context;

        public AnalyticsService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<object> GetMetricasPeriodo(DateTime inicio, DateTime fim)
        {
            var ordens = await _context.OrdensServico
                .Where(os => os.DataCriacao >= inicio && os.DataCriacao <= fim)
                .ToListAsync();

            var impressoras = await _context.Impressoras.ToListAsync();

            return new
            {
                Periodo = $"{inicio:dd/MM} a {fim:dd/MM}",
                TotalOrdens = ordens.Count,
                OrdensConcluidas = ordens.Count(os => os.Status == StatusOS.Concluida),
                OrdensPendentes = ordens.Count(os => os.Status == StatusOS.Pendente),
                TaxaConclusao = ordens.Count > 0 ? 
                    (double)ordens.Count(os => os.Status == StatusOS.Concluida) / ordens.Count * 100 : 0,
                
                TempoMedioProducao = ordens.Where(os => os.Status == StatusOS.Concluida).Average(os => 
                    (os.DataConclusao - os.DataCriacao)?.TotalMinutes ?? 0),
                
                ImpressoraMaisUtilizada = impressoras
                    .OrderByDescending(i => ordens.Count(os => os.ImpressoraId == i.Id))
                    .Select(i => new { i.Nome, Utilizacao = ordens.Count(os => os.ImpressoraId == i.Id) })
                    .FirstOrDefault(),
                
                PrioridadeDistribuicao = ordens
                    .GroupBy(os => os.Prioridade)
                    .Select(g => new { Prioridade = g.Key, Quantidade = g.Count() })
                    .ToList()
            };
        }

        public async Task<object> GetEficienciaImpressoras()
        {
            var ordens = await _context.OrdensServico
                .Where(os => os.Status == StatusOS.Concluida && os.ImpressoraId.HasValue)
                .ToListAsync();

            var impressoras = await _context.Impressoras.ToListAsync();

            var eficiencia = impressoras.Select(imp => new
            {
                Impressora = imp.Nome,
                TotalOrdens = ordens.Count(os => os.ImpressoraId == imp.Id),
                TempoMedio = ordens.Where(os => os.ImpressoraId == imp.Id)
                    .Average(os => (os.DataConclusao - os.DataCriacao)?.TotalMinutes ?? 0),
                Utilizacao = (double)ordens.Count(os => os.ImpressoraId == imp.Id) / Math.Max(ordens.Count, 1) * 100
            })
            .OrderByDescending(e => e.Utilizacao)
            .ToList();

            return eficiencia;
        }

        public async Task<object> GetPrevisaoProducao()
        {
            var ordensPendentes = await _context.OrdensServico
                .Where(os => os.Status == StatusOS.Pendente || os.Status == StatusOS.EmImpressao)
                .ToListAsync();

            var impressorasDisponiveis = await _context.Impressoras
                .Where(i => i.Status == StatusImpressora.Disponivel)
                .CountAsync();

            var tempoTotalEstimado = ordensPendentes.Sum(os => os.TempoEstimadoMinutos);
            var capacidadeDiaria = impressorasDisponiveis * 480; // 8 horas em minutos

            return new
            {
                OrdensPendentes = ordensPendentes.Count,
                TempoTotalEstimado = tempoTotalEstimado,
                DiasParaConclusao = capacidadeDiaria > 0 ? Math.Ceiling((double)tempoTotalEstimado / capacidadeDiaria) : 0,
                ImpressorasDisponiveis = impressorasDisponiveis,
                CapacidadeDiaria = capacidadeDiaria
            };
        }
    }
}