using PrintFlowAI.Models;
using PrintFlowAI.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace PrintFlowAI.Services
{
    public class ControleProducaoService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<ControleProducaoService> _logger;

        public ControleProducaoService(IServiceProvider serviceProvider, ILogger<ControleProducaoService> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Serviço de Controle de Produção iniciado.");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using (var scope = _serviceProvider.CreateScope())
                    {
                        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                        await ProcessarOrdensEmProducao(context);
                    }
                    
                    // Verificar a cada 30 segundos
                    await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Erro no serviço de controle de produção");
                    await Task.Delay(TimeSpan.FromSeconds(60), stoppingToken);
                }
            }
        }

        private async Task ProcessarOrdensEmProducao(ApplicationDbContext context)
        {
            var ordensEmProducao = await context.OrdensServico
                .Where(os => os.Status == StatusOS.EmImpressao && os.DataInicioImpressao.HasValue)
                .ToListAsync();

            foreach (var os in ordensEmProducao)
            {
                var tempoDecorrido = DateTime.Now - os.DataInicioImpressao.Value;
                var tempoTotalEstimado = TimeSpan.FromMinutes(os.TempoEstimadoMinutos);
                
                // Calcular progresso (0-100%)
                os.ProgressoAtual = (int)Math.Min(100, (tempoDecorrido.TotalMinutes / os.TempoEstimadoMinutos) * 100);

                _logger.LogInformation($"OS {os.NumeroOS} - Progresso: {os.ProgressoAtual}%");

                // Se tempo acabou, concluir automaticamente
                if (tempoDecorrido >= tempoTotalEstimado)
                {
                    await ConcluirOSAutomaticamente(context, os);
                }
            }

            if (ordensEmProducao.Any())
            {
                await context.SaveChangesAsync();
                _logger.LogInformation($"{ordensEmProducao.Count} ordens em produção processadas.");
            }
        }

        private async Task ConcluirOSAutomaticamente(ApplicationDbContext context, OrdemServico os)
        {
            os.Status = StatusOS.Concluida;
            os.DataFimImpressao = DateTime.Now;
            os.DataConclusao = DateTime.Now;
            os.ProgressoAtual = 100;

            // Liberar impressora
            if (os.ImpressoraId.HasValue)
            {
                var impressora = await context.Impressoras.FindAsync(os.ImpressoraId.Value);
                if (impressora != null)
                {
                    impressora.Status = StatusImpressora.Disponivel;
                    impressora.OrdemServicoAtualId = null;
                    _logger.LogInformation($"Impressora {impressora.Nome} liberada automaticamente.");
                }
            }

            _logger.LogInformation($"OS {os.NumeroOS} concluída automaticamente após {os.TempoEstimadoMinutos} minutos.");
        }
    }
}