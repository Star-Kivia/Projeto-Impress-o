using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PrintFlowAI.Models
{
    public class OrdemServico
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        
        [Required]
        [MaxLength(20)]
        public string NumeroOS { get; set; } = string.Empty;
        
        [Required]
        [MaxLength(100)]
        public string Cliente { get; set; } = string.Empty;
        
        [Required]
        [MaxLength(500)]
        public string Descricao { get; set; } = string.Empty;
        
        public int Quantidade { get; set; }
        
        [Required]
        [MaxLength(50)]
        public string TipoPapel { get; set; } = string.Empty;
        
        public bool UsaPantone { get; set; }
        
        public DateTime PrazoEntrega { get; set; }
        
        [Required]
        public PrioridadeOS Prioridade { get; set; }
        
        [Required]
        public StatusOS Status { get; set; } = StatusOS.Pendente;
        
        public int? ImpressoraId { get; set; }
        
        public int TempoEstimadoMinutos { get; set; }
        
        public DateTime DataCriacao { get; set; } = DateTime.Now;
        public DateTime? DataConclusao { get; set; }
        
        // NOVOS CAMPOS PARA CONTROLE AUTOMÁTICO
        public DateTime? DataInicioImpressao { get; set; }
        public DateTime? DataFimImpressao { get; set; }
        public int ProgressoAtual { get; set; } = 0;
    }

    public enum PrioridadeOS
    {
        Urgente,
        Tecnico,
        Producao,
        Padrao
    }

    public enum StatusOS
    {
        Pendente,
        EmImpressao,
        Concluida
    }
}