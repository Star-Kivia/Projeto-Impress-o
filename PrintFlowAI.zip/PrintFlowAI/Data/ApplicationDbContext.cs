using Microsoft.EntityFrameworkCore;
using PrintFlowAI.Models;

namespace PrintFlowAI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<OrdemServico> OrdensServico { get; set; }
        public DbSet<Impressora> Impressoras { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configuração de Usuario
            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.HasKey(u => u.Id);
                entity.Property(u => u.Email).IsRequired().HasMaxLength(100);
                entity.Property(u => u.Senha).IsRequired().HasMaxLength(100);
                entity.Property(u => u.Nome).IsRequired().HasMaxLength(100);
                entity.Property(u => u.Tipo).IsRequired();
                entity.HasIndex(u => u.Email).IsUnique();
            });

            // Configuração de OrdemServico
            modelBuilder.Entity<OrdemServico>(entity =>
            {
                entity.HasKey(os => os.Id);
                entity.Property(os => os.NumeroOS).IsRequired().HasMaxLength(20);
                entity.Property(os => os.Cliente).IsRequired().HasMaxLength(100);
                entity.Property(os => os.Descricao).IsRequired().HasMaxLength(500);
                entity.Property(os => os.TipoPapel).IsRequired().HasMaxLength(50);
                entity.Property(os => os.Prioridade).IsRequired();
                entity.Property(os => os.Status).IsRequired();
                
                // Relacionamento com Impressora (opcional)
                entity.HasOne<Impressora>()
                    .WithMany()
                    .HasForeignKey(os => os.ImpressoraId)
                    .IsRequired(false)
                    .OnDelete(DeleteBehavior.SetNull);
            });

            // Configuração de Impressora
            modelBuilder.Entity<Impressora>(entity =>
            {
                entity.HasKey(i => i.Id);
                entity.Property(i => i.Nome).IsRequired().HasMaxLength(50);
                entity.Property(i => i.Categoria).IsRequired().HasMaxLength(20);
                entity.Property(i => i.Status).IsRequired();
            });

            // Dados iniciais
            modelBuilder.Entity<Usuario>().HasData(
                new Usuario 
                { 
                    Id = 1, 
                    Email = "pre@printflow.com", 
                    Senha = "123", 
                    Nome = "Operador Pré-Impressão",
                    Tipo = TipoUsuario.PreImpressao,
                    Ativo = true
                },
                new Usuario 
                { 
                    Id = 2, 
                    Email = "impressao@printflow.com", 
                    Senha = "123", 
                    Nome = "Operador Impressão",
                    Tipo = TipoUsuario.Impressao,
                    Ativo = true
                }
            );

            modelBuilder.Entity<Impressora>().HasData(
                new Impressora 
                { 
                    Id = 1, 
                    Nome = "Impressora A", 
                    VelocidadeMinutos = 35, 
                    Status = StatusImpressora.Disponivel, 
                    Categoria = "Urgente" 
                },
                new Impressora 
                { 
                    Id = 2, 
                    Nome = "Impressora B", 
                    VelocidadeMinutos = 45, 
                    Status = StatusImpressora.Disponivel, 
                    Categoria = "Tecnico" 
                },
                new Impressora 
                { 
                    Id = 3, 
                    Nome = "Impressora C", 
                    VelocidadeMinutos = 55, 
                    Status = StatusImpressora.Disponivel, 
                    Categoria = "Producao" 
                },
                new Impressora 
                { 
                    Id = 4, 
                    Nome = "Impressora D", 
                    VelocidadeMinutos = 65, 
                    Status = StatusImpressora.Disponivel, 
                    Categoria = "Padrao" 
                }
            );
        }
    }
}