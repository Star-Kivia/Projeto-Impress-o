using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using PrintFlowAI.Models;
using PrintFlowAI.Data;
using PrintFlowAI.Services;

namespace PrintFlowAI.Controllers
{
    [Authorize]
    public class OrdemServicoController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly OrdemServicoService _osService;

        public OrdemServicoController(ApplicationDbContext context)
        {
            _context = context;
            _osService = new OrdemServicoService();
        }

        public async Task<IActionResult> Index()
        {
            var ordens = await _context.OrdensServico
                .OrderByDescending(os => os.DataCriacao)
                .ToListAsync();
            return View(ordens);
        }

        [Authorize(Roles = "PreImpressao")]
        public IActionResult Criar()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "PreImpressao")]
        public async Task<IActionResult> Criar(OrdemServico os)
        {
            if (ModelState.IsValid)
            {
                os.DataCriacao = DateTime.Now;
                
                // Classificação e distribuição automática
                var impressoras = await _context.Impressoras.ToListAsync();
                var resultado = _osService.ProcessarNovaOS(os, impressoras);
                
                os.NumeroOS = await GerarNumeroOS();
                os.Prioridade = resultado.Prioridade;
                os.TempoEstimadoMinutos = resultado.TempoEstimado;
                
                if (resultado.ImpressoraId.HasValue)
                {
                    os.ImpressoraId = resultado.ImpressoraId;
                    os.Status = StatusOS.EmImpressao;
                    
                    // Atualizar impressora
                    var impressora = await _context.Impressoras.FindAsync(resultado.ImpressoraId.Value);
                    if (impressora != null)
                    {
                        impressora.Status = StatusImpressora.Ocupada;
                        impressora.OrdemServicoAtualId = os.Id;
                    }
                }
                else
                {
                    os.Status = StatusOS.Pendente;
                }
                
                _context.OrdensServico.Add(os);
                await _context.SaveChangesAsync();
                
                return RedirectToAction("Index");
            }
            return View(os);
        }

        [Authorize(Roles = "Impressao")]
        public async Task<IActionResult> IniciarProducao(int id)
        {
            var os = await _context.OrdensServico.FindAsync(id);
            if (os != null && os.Status == StatusOS.Pendente)
            {
                var impressoras = await _context.Impressoras.ToListAsync();
                var resultado = _osService.DistribuirOS(os, impressoras);
                
                if (resultado.ImpressoraId.HasValue)
                {
                    os.ImpressoraId = resultado.ImpressoraId;
                    os.Status = StatusOS.EmImpressao;
                    
                    var impressora = await _context.Impressoras.FindAsync(resultado.ImpressoraId.Value);
                    if (impressora != null)
                    {
                        impressora.Status = StatusImpressora.Ocupada;
                        impressora.OrdemServicoAtualId = os.Id;
                    }
                    
                    await _context.SaveChangesAsync();
                }
            }
            return RedirectToAction("Index");
        }

        [Authorize(Roles = "Impressao")]
        public async Task<IActionResult> Concluir(int id)
        {
            var os = await _context.OrdensServico.FindAsync(id);
            if (os != null && os.Status == StatusOS.EmImpressao)
            {
                os.Status = StatusOS.Concluida;
                os.DataConclusao = DateTime.Now;
                
                // Liberar impressora
                if (os.ImpressoraId.HasValue)
                {
                    var impressora = await _context.Impressoras.FindAsync(os.ImpressoraId.Value);
                    if (impressora != null)
                    {
                        impressora.Status = StatusImpressora.Disponivel;
                        impressora.OrdemServicoAtualId = null;
                    }
                }
                
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Index");
        }

        private async Task<string> GerarNumeroOS()
        {
            var ultimaOS = await _context.OrdensServico
                .OrderByDescending(os => os.Id)
                .FirstOrDefaultAsync();
                
            var proximoNumero = (ultimaOS?.Id ?? 0) + 1;
            return $"OS{proximoNumero:0000}";
        }
    }
}