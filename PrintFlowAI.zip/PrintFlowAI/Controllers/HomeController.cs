using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using PrintFlowAI.Models;
using PrintFlowAI.Data;
using System.Security.Claims;

namespace PrintFlowAI.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var usuarioTipo = User.FindFirst(ClaimTypes.Role)?.Value;
            var usuarioNome = User.FindFirst(ClaimTypes.Name)?.Value;

            var ordensServico = await _context.OrdensServico.ToListAsync();
            var impressoras = await _context.Impressoras.ToListAsync();

            var viewModel = new DashboardViewModel
            {
                OSPendentes = ordensServico.Count(os => os.Status == StatusOS.Pendente),
                OSEmProducao = ordensServico.Count(os => os.Status == StatusOS.EmImpressao),
                OSConcluidas = ordensServico.Count(os => os.Status == StatusOS.Concluida),
                Eficiencia = CalcularEficiencia(ordensServico),
                Impressoras = impressoras,
                FilaProducao = ordensServico.Where(os => os.Status == StatusOS.EmImpressao).ToList(),
                UsuarioLogado = usuarioNome ?? "Operador",
                TipoUsuario = Enum.Parse<TipoUsuario>(usuarioTipo ?? "PreImpressao")
            };

            return View(viewModel);
        }

        private double CalcularEficiencia(List<OrdemServico> ordensServico)
        {
            var totalConcluidas = ordensServico.Count(os => os.Status == StatusOS.Concluida);
            var totalOS = ordensServico.Count;
            return totalOS > 0 ? (double)totalConcluidas / totalOS * 100 : 0;
        }
    }
}