using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using PrintFlowAI.Models;
using PrintFlowAI.Data;
using PrintFlowAI.Services;

namespace PrintFlowAI.Controllers.Api
{
    [Authorize]
    public class DashboardController : BaseApiController
    {
        private readonly ApplicationDbContext _context;
        private readonly AnalyticsService _analyticsService;

        public DashboardController(ApplicationDbContext context, AnalyticsService analyticsService)
        {
            _context = context;
            _analyticsService = analyticsService;
        }

        [HttpGet("metrics")]
        public async Task<IActionResult> GetMetrics()
        {
            try
            {
                var ordensServico = await _context.OrdensServico.ToListAsync();
                var impressoras = await _context.Impressoras.ToListAsync();

                var metrics = new
                {
                    OSPendentes = ordensServico.Count(os => os.Status == StatusOS.Pendente),
                    OSEmProducao = ordensServico.Count(os => os.Status == StatusOS.EmImpressao),
                    OSConcluidas = ordensServico.Count(os => os.Status == StatusOS.Concluida),
                    Eficiencia = CalcularEficiencia(ordensServico),
                    ImpressorasDisponiveis = impressoras.Count(i => i.Status == StatusImpressora.Disponivel),
                    ImpressorasOcupadas = impressoras.Count(i => i.Status == StatusImpressora.Ocupada),
                    ImpressorasManutencao = impressoras.Count(i => i.Status == StatusImpressora.Manutencao),
                    UltimaAtualizacao = DateTime.Now
                };

                return Ok(metrics);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao buscar métricas", details = ex.Message });
            }
        }

        [HttpGet("impressoras")]
        public async Task<IActionResult> GetImpressoras()
        {
            try
            {
                var impressoras = await _context.Impressoras
                    .Select(i => new
                    {
                        i.Id,
                        i.Nome,
                        i.VelocidadeMinutos,
                        i.Status,
                        i.Categoria,
                        OrdemAtual = i.OrdemServicoAtualId.HasValue ? 
                            _context.OrdensServico
                                .Where(os => os.Id == i.OrdemServicoAtualId)
                                .Select(os => new { os.NumeroOS, os.Descricao, os.ProgressoAtual })
                                .FirstOrDefault() : null,
                        i.DataManutencao
                    })
                    .ToListAsync();

                return Ok(impressoras);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao buscar impressoras", details = ex.Message });
            }
        }

        [HttpGet("fila-producao")]
        public async Task<IActionResult> GetFilaProducao()
        {
            try
            {
                var fila = await _context.OrdensServico
                    .Where(os => os.Status == StatusOS.EmImpressao || os.Status == StatusOS.Pendente)
                    .OrderBy(os => os.Prioridade)
                    .ThenBy(os => os.PrazoEntrega)
                    .Select(os => new
                    {
                        os.Id,
                        os.NumeroOS,
                        os.Descricao,
                        os.Cliente,
                        os.Prioridade,
                        os.Status,
                        os.ImpressoraId,
                        os.TempoEstimadoMinutos,
                        os.PrazoEntrega,
                        os.ProgressoAtual,
                        os.DataInicioImpressao,
                        TempoRestante = os.Status == StatusOS.EmImpressao ? 
                            CalcularTempoRestante(os) : null,
                        PrevisaoTermino = os.Status == StatusOS.EmImpressao && os.DataInicioImpressao.HasValue ?
                            os.DataInicioImpressao.Value.AddMinutes(os.TempoEstimadoMinutos) : null
                    })
                    .ToListAsync();

                return Ok(fila);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao buscar fila de produção", details = ex.Message });
            }
        }

        [HttpGet("ordens-ativas")]
        public async Task<IActionResult> GetOrdensAtivas()
        {
            try
            {
                var ordens = await _context.OrdensServico
                    .Where(os => os.Status == StatusOS.EmImpressao)
                    .Select(os => new
                    {
                        os.Id,
                        os.NumeroOS,
                        os.Descricao,
                        Impressora = _context.Impressoras
                            .Where(i => i.Id == os.ImpressoraId)
                            .Select(i => i.Nome)
                            .FirstOrDefault(),
                        os.ProgressoAtual,
                        TempoDecorrido = DateTime.Now - os.DataCriacao,
                        os.TempoEstimadoMinutos,
                        TempoRestante = CalcularTempoRestante(os),
                        PrevisaoTermino = os.DataInicioImpressao.HasValue ?
                            os.DataInicioImpressao.Value.AddMinutes(os.TempoEstimadoMinutos) : null
                    })
                    .ToListAsync();

                return Ok(ordens);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao buscar ordens ativas", details = ex.Message });
            }
        }

        [HttpPost("atualizar-status-impressora/{id}")]
        [Authorize(Policy = "Impressao")]
        public async Task<IActionResult> AtualizarStatusImpressora(int id, [FromBody] StatusImpressora novoStatus)
        {
            try
            {
                var impressora = await _context.Impressoras.FindAsync(id);
                if (impressora == null)
                    return NotFound(new { error = "Impressora não encontrada" });

                impressora.Status = novoStatus;
                if (novoStatus == StatusImpressora.Manutencao)
                {
                    impressora.DataManutencao = DateTime.Now;
                    impressora.OrdemServicoAtualId = null;
                }

                await _context.SaveChangesAsync();

                return Ok(new { message = "Status atualizado com sucesso" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao atualizar status", details = ex.Message });
            }
        }

        [HttpPost("iniciar-producao/{id}")]
        [Authorize(Policy = "Impressao")]
        public async Task<IActionResult> IniciarProducao(int id)
        {
            try
            {
                var os = await _context.OrdensServico.FindAsync(id);
                if (os == null || os.Status != StatusOS.Pendente)
                    return BadRequest(new { error = "OS não encontrada ou já em produção" });

                var impressorasDisponiveis = await _context.Impressoras
                    .Where(i => i.Status == StatusImpressora.Disponivel)
                    .ToListAsync();

                if (!impressorasDisponiveis.Any())
                    return BadRequest(new { error = "Nenhuma impressora disponível" });

                // Distribuição inteligente
                var impressoraId = DistribuirOS(os, impressorasDisponiveis);
                os.ImpressoraId = impressoraId;
                os.Status = StatusOS.EmImpressao;
                os.DataInicioImpressao = DateTime.Now; // NOVO: Registrar início
                os.ProgressoAtual = 0; // NOVO: Iniciar progresso

                var impressora = await _context.Impressoras.FindAsync(impressoraId);
                if (impressora != null)
                {
                    impressora.Status = StatusImpressora.Ocupada;
                    impressora.OrdemServicoAtualId = os.Id;
                }

                await _context.SaveChangesAsync();

                var previsaoTermino = DateTime.Now.AddMinutes(os.TempoEstimadoMinutos);

                return Ok(new { 
                    message = "Produção iniciada", 
                    impressora = impressora?.Nome,
                    tempoEstimado = os.TempoEstimadoMinutos,
                    previsaoTermino = previsaoTermino.ToString("dd/MM/yyyy HH:mm"),
                    progresso = os.ProgressoAtual
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao iniciar produção", details = ex.Message });
            }
        }

        [HttpPost("concluir-producao/{id}")]
        [Authorize(Policy = "Impressao")]
        public async Task<IActionResult> ConcluirProducao(int id)
        {
            try
            {
                var os = await _context.OrdensServico.FindAsync(id);
                if (os == null || os.Status != StatusOS.EmImpressao)
                    return BadRequest(new { error = "OS não encontrada ou não está em produção" });

                os.Status = StatusOS.Concluida;
                os.DataConclusao = DateTime.Now;
                os.DataFimImpressao = DateTime.Now; // NOVO: Registrar fim
                os.ProgressoAtual = 100; // NOVO: Completar progresso

                if (os.ImpressoraId.HasValue)
                {
                    var impressora = await _context.Impressoras.FindAsync(os.ImpressoraId.Value);
                    if (impressora != null)
                    {
                        impressora.Status = StatusImpressora.Disponivel;
                        impressora.OrdemServicoAtualId = null;
                    }
                }

                await _context.SaveChangesAsync();

                return Ok(new { message = "Produção concluída com sucesso" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao concluir produção", details = ex.Message });
            }
        }

        [HttpGet("progresso-os/{id}")]
        public async Task<IActionResult> GetProgressoOS(int id)
        {
            try
            {
                var os = await _context.OrdensServico
                    .Where(o => o.Id == id)
                    .Select(o => new
                    {
                        o.Id,
                        o.NumeroOS,
                        o.Descricao,
                        o.ProgressoAtual,
                        o.TempoEstimadoMinutos,
                        o.DataInicioImpressao,
                        TempoDecorrido = o.DataInicioImpressao.HasValue ? 
                            (DateTime.Now - o.DataInicioImpressao.Value).TotalMinutes : 0,
                        TempoRestante = o.DataInicioImpressao.HasValue ? 
                            Math.Max(0, o.TempoEstimadoMinutos - (DateTime.Now - o.DataInicioImpressao.Value).TotalMinutes) : o.TempoEstimadoMinutos,
                        PrevisaoTermino = o.DataInicioImpressao?.AddMinutes(o.TempoEstimadoMinutos)
                    })
                    .FirstOrDefaultAsync();

                if (os == null)
                    return NotFound();

                return Ok(os);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Erro ao buscar progresso", details = ex.Message });
            }
        }

        // Métodos auxiliares
        private double CalcularEficiencia(List<OrdemServico> ordensServico)
        {
            var totalConcluidas = ordensServico.Count(os => os.Status == StatusOS.Concluida);
            var totalOS = ordensServico.Count;
            return totalOS > 0 ? (double)totalConcluidas / totalOS * 100 : 0;
        }

        private int? CalcularTempoRestante(OrdemServico os)
        {
            if (os.Status != StatusOS.EmImpressao || !os.DataInicioImpressao.HasValue)
                return null;

            var tempoDecorrido = DateTime.Now - os.DataInicioImpressao.Value;
            var tempoRestante = os.TempoEstimadoMinutos - tempoDecorrido.TotalMinutes;
            return (int)Math.Max(0, tempoRestante);
        }

        private int CalcularProgresso(OrdemServico os)
        {
            if (os.Status != StatusOS.EmImpressao || !os.DataInicioImpressao.HasValue)
                return 0;

            var tempoDecorrido = DateTime.Now - os.DataInicioImpressao.Value;
            var progresso = (tempoDecorrido.TotalMinutes / os.TempoEstimadoMinutos) * 100;
            return (int)Math.Min(100, Math.Max(0, progresso));
        }

        private int DistribuirOS(OrdemServico os, List<Impressora> impressorasDisponiveis)
        {
            return os.Prioridade switch
            {
                PrioridadeOS.Urgente => impressorasDisponiveis
                    .FirstOrDefault(i => i.Categoria == "Urgente")?.Id 
                    ?? impressorasDisponiveis.OrderBy(i => i.VelocidadeMinutos).First().Id,
                    
                PrioridadeOS.Tecnico => impressorasDisponiveis
                    .FirstOrDefault(i => i.Categoria == "Tecnico")?.Id
                    ?? impressorasDisponiveis.OrderBy(i => i.VelocidadeMinutos).First().Id,
                    
                PrioridadeOS.Producao => impressorasDisponiveis
                    .FirstOrDefault(i => i.Categoria == "Producao")?.Id
                    ?? impressorasDisponiveis.OrderBy(i => i.VelocidadeMinutos).First().Id,
                    
                PrioridadeOS.Padrao => impressorasDisponiveis
                    .FirstOrDefault(i => i.Categoria == "Padrao")?.Id
                    ?? impressorasDisponiveis.OrderBy(i => i.VelocidadeMinutos).First().Id,
                    
                _ => impressorasDisponiveis.First().Id
            };
        }
    }
}