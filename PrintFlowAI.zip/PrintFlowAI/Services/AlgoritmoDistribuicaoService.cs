using PrintFlowAI.Models;

namespace PrintFlowAI.Services
{
    public class AlgoritmoDistribuicaoService
    {
        public class ResultadoDistribuicao
        {
            public int? ImpressoraId { get; set; }
            public int Pontuacao { get; set; }
            public string Motivo { get; set; } = string.Empty;
            public int TempoEstimado { get; set; }
        }

        public ResultadoDistribuicao DistribuirOS(OrdemServico os, List<Impressora> impressoras)
        {
            var impressorasDisponiveis = impressoras
                .Where(i => i.Status == StatusImpressora.Disponivel)
                .ToList();

            if (!impressorasDisponiveis.Any())
                return new ResultadoDistribuicao 
                { 
                    ImpressoraId = null,
                    Pontuacao = 0,
                    Motivo = "Nenhuma impressora disponível",
                    TempoEstimado = CalcularTempoEstimado(os)
                };

            // Calcular pontuação para cada impressora
            var rankings = impressorasDisponiveis
                .Select(imp => new
                {
                    Impressora = imp,
                    Pontuacao = CalcularPontuacao(os, imp),
                    TempoEstimado = CalcularTempoOS(os, imp)
                })
                .OrderByDescending(r => r.Pontuacao)
                .ThenBy(r => r.TempoEstimado)
                .ToList();

            var melhor = rankings.First();

            return new ResultadoDistribuicao
            {
                ImpressoraId = melhor.Impressora.Id,
                Pontuacao = melhor.Pontuacao,
                Motivo = GerarMotivo(os, melhor.Impressora, melhor.Pontuacao),
                TempoEstimado = melhor.TempoEstimado
            };
        }

        private int CalcularPontuacao(OrdemServico os, Impressora imp)
        {
            int pontuacao = 0;

            // 1. Compatibilidade de Categoria (40 pontos máximo)
            pontuacao += CalcularCompatibilidadeCategoria(os, imp);

            // 2. Eficiência de Tempo (30 pontos máximo)
            pontuacao += CalcularEficienciaTempo(os, imp);

            // 3. Balanceamento de Carga (20 pontos máximo)
            pontuacao += CalcularBalanceamentoCarga(imp);

            // 4. Urgência (10 pontos máximo)
            pontuacao += CalcularUrgencia(os);

            return pontuacao;
        }

        private int CalcularCompatibilidadeCategoria(OrdemServico os, Impressora imp)
        {
            var prioridade = ClassificarPrioridade(os);
            
            return (prioridade, imp.Categoria.ToLower()) switch
            {
                (PrioridadeOS.Urgente, "urgente") => 40,
                (PrioridadeOS.Urgente, _) => 20,
                
                (PrioridadeOS.Tecnico, "tecnico") => 40,
                (PrioridadeOS.Tecnico, _) => os.UsaPantone ? 10 : 20,
                
                (PrioridadeOS.Producao, "producao") => 40,
                (PrioridadeOS.Producao, _) => os.Quantidade > 1000 ? 15 : 25,
                
                (PrioridadeOS.Padrao, "padrao") => 40,
                (PrioridadeOS.Padrao, _) => 30,
                
                _ => 20
            };
        }

        private int CalcularEficienciaTempo(OrdemServico os, Impressora imp)
        {
            var tempoBase = CalcularTempoBase(os);
            var fatorVelocidade = (double)imp.VelocidadeMinutos / 35; // Normalizado pela impressora mais rápida
            
            var tempoEstimado = tempoBase * fatorVelocidade;
            var tempoIdeal = tempoBase * 0.8; // 20% mais rápido que o base

            if (tempoEstimado <= tempoIdeal)
                return 30;
            else if (tempoEstimado <= tempoBase)
                return 20;
            else
                return 10;
        }

        private int CalcularBalanceamentoCarga(Impressora imp)
        {
            // Simulação - em produção real, teríamos histórico de uso
            var cargaRelativa = new Random().Next(1, 100);
            
            if (cargaRelativa <= 30) return 20;    // Baixa carga
            else if (cargaRelativa <= 70) return 15; // Carga média
            else return 10;                         // Alta carga
        }

        private int CalcularUrgencia(OrdemServico os)
        {
            var horasRestantes = (os.PrazoEntrega - DateTime.Now).TotalHours;

            if (horasRestantes <= 24) return 10;    // Muito urgente
            else if (horasRestantes <= 48) return 7; // Urgente
            else if (horasRestantes <= 72) return 4; // Moderado
            else return 1;                           // Normal
        }

        private PrioridadeOS ClassificarPrioridade(OrdemServico os)
        {
            // 🔴 URGENTE: Prazo crítico
            if (os.PrazoEntrega <= DateTime.Now.AddHours(24))
                return PrioridadeOS.Urgente;
            
            // 🔵 TÉCNICO: Requisitos especiais
            if (os.UsaPantone || os.TipoPapel.Contains("especial") || os.TipoPapel.Contains("premium"))
                return PrioridadeOS.Tecnico;
            
            // 🟢 PRODUÇÃO: Volume alto
            if (os.Quantidade > 1000)
                return PrioridadeOS.Producao;
            
            // 🟡 PADRÃO: Demais casos
            return PrioridadeOS.Padrao;
        }

        private int CalcularTempoOS(OrdemServico os, Impressora imp)
        {
            var tempoBase = CalcularTempoBase(os);
            var fatorVelocidade = (double)imp.VelocidadeMinutos / 35;
            return (int)(tempoBase * fatorVelocidade);
        }

        private int CalcularTempoBase(OrdemServico os)
        {
            var tempoBase = 30; // tempo base em minutos
            
            // Ajuste por quantidade
            if (os.Quantidade > 1000) tempoBase += 60;
            else if (os.Quantidade > 500) tempoBase += 30;
            else if (os.Quantidade > 100) tempoBase += 15;

            // Ajuste por complexidade
            if (os.UsaPantone) tempoBase += 20;
            if (os.TipoPapel.Contains("especial")) tempoBase += 15;
            if (os.TipoPapel.Contains("premium")) tempoBase += 10;

            return tempoBase;
        }

        private int CalcularTempoEstimado(OrdemServico os)
        {
            return CalcularTempoBase(os);
        }

        private string GerarMotivo(OrdemServico os, Impressora imp, int pontuacao)
        {
            var prioridade = ClassificarPrioridade(os);

            return pontuacao switch
            {
                >= 80 => $"Melhor compatibilidade: {prioridade} → {imp.Categoria}",
                >= 60 => $"Boa eficiência para {os.Descricao}",
                >= 40 => $"Distribuição balanceada para {imp.Nome}",
                _ => $"Distribuição padrão para {imp.Nome}"
            };
        }
    }
}